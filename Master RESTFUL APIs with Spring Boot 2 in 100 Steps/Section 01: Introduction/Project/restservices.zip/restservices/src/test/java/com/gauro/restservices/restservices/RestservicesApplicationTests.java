package com.gauro.restservices.restservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
